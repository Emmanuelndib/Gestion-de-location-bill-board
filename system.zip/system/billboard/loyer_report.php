<?php
session_start();
include('db.php');
$you=$_SESSION['SESS_ADMIN_ID'] ;


?>



<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table width="482" height="108" border="1">
  <tr>
    <td>Nom</td>
    <td>Date Entre</td>
    <td>End Date</td>
    <td>Nombre de mois</td>
  </tr>
   <?php
	 include('db.php');
	   
		$q="select *from rent_tbl where";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
  <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>

             <tr>
             
           
    <td><?php echo $row ['tenant_full_name']?></td>
    <td><?php echo $row['start_date']?></td>
    <td><?php echo $row['end_date']?></td>
    <td><?php echo $row['day_remained']?></td>
  </tr>
<?php
		}
   ?>
</table>
</body>
</html>