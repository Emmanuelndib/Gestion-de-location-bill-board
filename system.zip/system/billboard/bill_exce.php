<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$date_e=$_POST['start'];$date_e=mysqli_real_escape_string($con,$date_e);

$bill_t=$_POST['title'];$bill_t=mysqli_real_escape_string($con,$bill_t);


$bil_from=$_POST['origine'];$bil_from=mysqli_real_escape_string($con,$bil_from);

$amount=$_POST['bill_amount'];$amount=mysqli_real_escape_string($con,$amount);
$paid=$_POST['paye'];$paid=mysqli_real_escape_string($con,$paid);




$t_name=$_POST['fname'];$t_name=mysqli_real_escape_string($con,$t_name);
$landlord=$_POST['lname'];$landlord=mysqli_real_escape_string($con,$landlord);
$id_t=$_POST['id_tenant'];$id_t=mysqli_real_escape_string($con,$id_t);
	


// insert images 
	
	$rd2 = mt_rand(1000,9999)."_File";  
            $filename = basename($_FILES['uploaded']['name']);
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $newname="images/".$filename;

         move_uploaded_file($_FILES['uploaded']['tmp_name'],$newname);
	




$q="insert into facture_tbl set fact_title='$bill_t',fact_from='$bil_from',date='$date_e',tenant_name='$t_name',land_name='$landlord',tenant_id='$id_t',amount='$amount',pay='$paid',fac_pict='$newname'";
$result=mysqli_query($con,$q);

	
	}




$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> La facture  a été enregistré avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "tenant_management.php?id='.$id_t.'";
		}
		setTimeout(redirectAction,1000);
		</script>';
}



?>
