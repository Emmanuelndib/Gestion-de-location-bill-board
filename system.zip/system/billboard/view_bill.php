<?php
session_start();
include('db.php');
$me=$_REQUEST['id'];
$smu="select *from tenant_tbl where tenant_id='$me'";
$result=mysqli_query($con,$smu);
$kakule=mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/form_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />    
    <!--[if gt IE 8]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
    <![endif]-->                
    <title>Form Elements - Leo - Premium Admin Template</title>
    <link rel="icon" type="image/ico" href="favicon.ico"/>
    
    <link href="css/stylesheets.css" rel="stylesheet" type="text/css" />
    
    <link rel="stylesheet" type="text/css" href="tcal.css" />
    <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
    <!--[if lte IE 7]>
        <script type='text/javascript' src='js/other/lte-ie7.js'></script>
    <![endif]-->    
    
    <script type='text/javascript' src='js/jquery/jquery.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-ui-1.10.3.custom.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='js/jquery/globalize.js'></script>
    
    <script type='text/javascript' src='js/bootstrap/bootstrap.min.js'></script>
    <script type='text/javascript' src='js/cookies/jquery.cookies.2.2.0.min.js'></script>
    
    <script type='text/javascript' src='js/select2/select2.min.js'></script>
    <script type='text/javascript' src='js/uniform/jquery.uniform.min.js'></script>
    <script type='text/javascript' src='js/tagsinput/jquery.tagsinput.min.js'></script>
    <script type='text/javascript' src='js/multiselect/jquery.multi-select.js'></script>    
    <script type='text/javascript' src='js/ibutton/jquery.ibutton.min.js'></script>    
    <script type='text/javascript' src='js/colorpicker/colorpicker.js'></script>    
    <script type='text/javascript' src='js/timepicker/jquery-ui-timepicker-addon.js'></script>    
    
    <script type='text/javascript' src='js/scrollup/jquery.scrollUp.min.js'></script>
    
    <script type='text/javascript' src='js/plugins.js'></script>    
    <script type='text/javascript' src='js/actions.js'></script>
    
    








    
    <script type="text/javascript" src="tcal.js"></script>
    
    
    
    
    



</head>
<body>    
    
    <div id="wrapper">
        
        <div id="header">
            
            <div class="wrap">
                
                <a href="index-2.html" class="logo"></a>
                
                <div class="buttons fl">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_layout">
                            <span class="i-layout-8"></span>                            
                        </a>
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_screen">
                            <span class="i-stretch"></span>                            
                        </a>
                    </div>                    
                </div>

                
                <div class="buttons">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-cog"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Settings</h2>
                            </div>
                            <div class="content np">      
                                <div class="row">
                                    <div class="controls-row">
                                        <div class="col-md-3">Themes:</div>
                                        <div class="col-md-9 themes">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>
                                            <a href="#" class="dark tip" data-theme="themeDark" title="Dark"></a>
                                            <a href="#" class="simple tip" data-theme="themeSimple" title="Simple"></a>
                                            <div class="help-block">On click theme will changed and saved settings</div>
                                        </div>
                                    </div>               
                                    <div class="controls-row">
                                        <div class="col-md-3">Backgrounds:</div>
                                        <div class="col-md-9 backgrounds">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>                                            
                                            <a href="#" class="b_bcrosshatch" data-back="b_bcrosshatch"></a>
                                            <a href="#" class="b_crosshatch" data-back="b_crosshatch"></a>
                                            <a href="#" class="b_cube" data-back="b_cube"></a>
                                            <a href="#" class="b_dots" data-back="b_dots"></a>
                                            <a href="#" class="b_grid" data-back="b_grid"></a>
                                            <a href="#" class="b_hline" data-back="b_hline"></a>
                                            <a href="#" class="b_simple" data-back="b_simple"></a>
                                            <a href="#" class="b_vline" data-back="b_vline"></a>
                                            <div class="help-block">On click background will changed and saved settings</div>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                            <div class="footer">
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-chat"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Messages</h2>
                            </div>
                            <div class="content npb messages minify" id="messages"></div>
                            <div class="footer">
                                <div class="side fl">
                                    <button class="btn btn-link">Show all</button>
                                </div>
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">                        
                        <div class="btn-group">                        
                            <a href="#" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                                <span class="i-forward"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="#"><span class="i-profile"></span> Profile</a></li>
                                <li><a href="#"><span class="i-tools"></span> Controls</a></li>                                
                                <li><a href="#"><span class="i-locked"></span> Lock</a></li>
                                <li><a href="#"><span class="i-forward"></span> Logout</a></li>
                            </ul> 
                        </div>
                    </div>                
                </div>
                
            </div>
            
        </div>
        
        <div id="layout">
        
              <div id="sidebar">

                <div class="user">
                    <div class="pic">
                        
                         <img src="<?php echo $_SESSION['SESS_ADMIN_PIC']?>" width="161" height="150"/>
                    </div>
                    <div class="info">
                        <div class="name">
                            <a href="#">Welcome ,<?php echo $_SESSION['SESS_ADMIN_USERNAME']?></a>
                        </div>
                        
                    </div>
                </div>
 <p>&nbsp;</p>
  <p>&nbsp;</p>
<p>&nbsp;</p>
  <p>&nbsp;</p>
 <p>&nbsp;</p>
    
                <ul class="navigation">
                    <li>
                        <a href="home.php">Acceuil</a>
                    </li>
                   
                    
                    <li class="openable">
                        <a href="#">Gestion du System </a>
                        <ul>
                         
                            <li>
                             <a href="add_ld.php">Ajouter Bayeur</a>  
                            </li>
                            
                            <li>
                             <a href="view_ld2.php">Liste de Bayeurs</a>  
                            </li>
                            <li>
                             <a href="view_ld.php">Gestion de Bayeurs</a>  
                            </li>
                            <li>
                             <a href="anoucement.php">Ajouter Annonce</a>  
                            </li>
                            
                          
                            
                                                  
                        </ul>
                    </li> 
                    <li class="openable open">
                        <a href="#">Confuguration</a>
                        <ul>
                            <li class="active">
                                <a href="add_user.php">Ajouter Utilisateur</a>
                            </li>                            
                                                                                 
                            
                                                        
                           
                        </ul>                        
                    </li>                
                                                  
                             
                               
                    
                                       
                    
                  
                                      
                </ul>

            </div>


            <div id="content">                        
                <div class="wrap">
                    
                    <div class="head">
                        <div class="info">
                            <h1>Le  proprietaire <font color="#FF0000"><?php echo $kakule['land_name']?></font></h1>
                            <ul class="breadcrumb">
                                <li><a href="tenant_management.php?id=<?php echo $kakule['tenant_id']?>">Gestion</a></li>
                                <li><a href="bill.php?id=<?php echo $kakule['tenant_id']?>">Enregister Facture</a></li>
                              
                                
                                <p>
                              <center> <?php 
							   include('msg.php');
							   ?></center>
                            </ul>
                        </div>
                        
                        <div class="search">
                            <form action="" method="post">
                                <input type="text" class="form-control" placeholder="search..."/>                                
                                <button type="submit"><span class="i-calendar"></span></button>
                                <button type="submit"><span class="i-magnifier"></span></button>
                            </form>
                        </div>                        
                    </div>                                                                    
                    
                    <div class="container">
                        
                        <div class="row">

                            <div class="col-md-12">

                                     
                                       
                           
                        
                       <div class="block">
                                    <div class="head">
                                        <h2>Voir les factures de <font color="#FF0000"><?php echo $kakule['firstname']?></font></h2>
                                        <ul class="buttons">
                                            <li><a href="#" class="block_loading"><span class="i-cycle"></span></a></li>
                                            <li><a href="#" class="block_toggle"><span class="i-arrow-down-3"></span></a></li>
                                            <li><a href="#" class="block_remove"><span class="i-cancel-2"></span></a></li>
                                        </ul>                                        
                                    </div>
                                    <div class="content np">
                                        

                                        <table cellpadding="0" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>                                    
                                                    <th width="25%">Facture de</th>
                                                    <th width="25%">Intitule</th>
                                                    <th width="25%">Date </th>
                                                    <th width="25%">Montant</th> 
                                                     <th width="25%">Paid or Not </th>   
                                                    <th width="25%">Edit</th> 
                                                     <th width="25%">Delete</th>                                   
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
	 include('db.php');
	 
		$q="select *from facture_tbl where tenant_id='$me' order by fact_id desc";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
                                                <tr>                                    
                                                    <td><?php echo $row['fact_from']?></td>
                                                    <td><?php echo $row['fact_title']?></td>
                                                    
                                                       <td><?php echo $row['date']?></td>
                                                         <td><?php echo $row['amount']?></td>
                                                    
                                                    <td><?php echo $row['pay']?></td>
                                                     <td>Edit</td>
                                                    <td>Delete</td>                                    
                                                </tr>
                                               
                                               <?php
		}
											   ?> 
                                                
                                                                          
                                            </tbody>
                                        </table>                                        
                                        
                                    </div>
                                </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                       
                        
                        
                        
                                    </div>
                                                  
                    </div>
                        
                </div>
            </div>
            
        </div>

    </div>
    
</body>

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/form_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:20 GMT -->
</html>
