// JavaScript Document
function end_date()
{ var  s_date=document.getElementById('start_d');

var mont=document.getElementById('month');

GotoPage('ajaxperformance','request/end_date.php','st_date='+s_date.value+'&month_d='+mont.value+'','images/',2);
}

function add_value(val){
	
var enddate=document.getElementById('end_d');

enddate.value=val;


	
}
