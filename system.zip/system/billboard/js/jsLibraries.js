function endDate()
{
	var startDate=document.getElementById('startDateId').value;
	var nMonth=document.getElementById('nMonthId').value;
	GotoPage('dateWillOccurHereId','request/endDate.php','date='+startDate+'&n='+nMonth+'','images/',2);
	
}
function writeContent(id,val)
{
var content; content=document.getElementById(id);
if(content){content.innerHTML=val}	
}
function addVal(id,val)
{
	var input=document.getElementById(id);
	if(input)
	{
		input.value=val;
	}
}
function GotoPage(sectionId,path,req,fileSrcImg,langId,event,enterKey,FrontEnd)
{
	if(event){var charCode =(event.keyCode ? event.keyCode : event.which);}else{var charCode=0;}
	if(enterKey){var keyPressed=1;}else{keyPressed=0;}

	if(fileSrcImg)
	{
		var fileSrc=fileSrcImg;
	}
	else
	{
		var fileSrc='';
	}
	
	
	var loader;
	
	if(langId)
	{
		if(langId==1)
		{
			loader='<img src="'+fileSrcImg+'enLoader.gif"/>';
		}
		else if(langId==2)
		{
			loader='<img src="'+fileSrcImg+'frLoader.gif"/>';
		}
		else
		{
			loader='<img src="'+fileSrcImg+'loader.gif"/>';
		}
	}
	else
	{
		loader='<img src="'+fileSrcImg+'loader.gif"/>';
	}
	
	var version = detectIE();
	var iE;

	if (version === false) {
 	//alert('IE/Edge');
	iE=666;
	} else if (version >= 12) {
 	//alert('Edge ' + version);
	iE=777;
	} 
	else {
  	//alert('IE ' + version);
	iE=1;
	}

if(iE==1)
{
	    if(langId == 1)
		{
			loader='<img src="'+fileSrcImg+'enBrowser.gif"/>';
		}
		else if(langId==2)
		{
			loader='<img src="'+fileSrcImg+'frBrowser.gif"/>';
		}
		else
		{
			loader='<img src="'+fileSrcImg+'enBrowser.gif"/>'; 
		}
}
	if(FrontEnd){if(path!='#' && path!='modal.php'){path='pages/'+path+'.php';}else{path=path;}}
	var newR=getTheAllRequests(req);
	if(keyPressed < 1)
	{
	$.ajax({
      type: "POST",
      url: ""+path+"",
      data: ''+req+'&fullReq='+newR+'',
      cache: false,
      beforeSend: function () { 
        $('#'+sectionId).html(loader);
      },
      success: function(html) {    
        $("#"+sectionId).html( html );
      }
    });	
	}
	else
	{
		if(charCode ==13)
		{
			$.ajax({
      type: "POST",
      url: ""+path+"",
      data: ''+req+'&fullReq='+newR+'',
      cache: false,
      beforeSend: function () { 
        $('#'+sectionId).html(loader);
      },
      success: function(html) {    
        $("#"+sectionId).html( html );
      }
    });	
		}
	}
}
function getTheAllRequests(myRequests)
{
	var newReq='';
	
	var explod;
	
	var i;
	
	explod=myRequests.split('&');
	
	for(i=0; i< explod.length; i++)
	{
		newReq+= explod[i].replace('=','@_666')+'@_777';
	}
	return newReq.slice(0,-5);
}
function detectIE() {
  var ua = window.navigator.userAgent;

  // Test values; Uncomment to check result …

  // IE 10
  // ua = 'Mozilla/5.0 (compatible; MSIE 10.0; Windows NT 6.2; Trident/6.0)';
  
  // IE 11
  // ua = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';
  
  // Edge 12 (Spartan)
  // ua = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.71 Safari/537.36 Edge/12.0';
  
  // Edge 13
  // ua = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/46.0.2486.0 Safari/537.36 Edge/13.10586';

  var msie = ua.indexOf('MSIE ');
  if (msie > 0) {
    // IE 10 or older => return version number
    return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
  }

  var trident = ua.indexOf('Trident/');
  if (trident > 0) {
    // IE 11 => return version number
    var rv = ua.indexOf('rv:');
    return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
  }

  var edge = ua.indexOf('Edge/');
  if (edge > 0) {
    // Edge (IE 12+) => return version number
    return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
  }

  // other browser
  return false;
}