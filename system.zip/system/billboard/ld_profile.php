<?php
session_start();
include('db.php');
$me=$_REQUEST['id'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
  <?php
	 include('db.php');
	   
		$q="select *from land_lord_tbl  where land_id='$me'";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
  <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
  <table width="451" border="0" bgcolor="">
    <tr>
      
      <td width="216"><img src="<?php echo $row['ld_pic']?>" height="169" width="188" /></td>
      <td width="225" bgcolor="#FFFFFF">
      <ul>
      <li><font size="2">Nom : <?php echo $row['firstname']?></font></li>
      <li><font size="2">Postnom: <?php echo $row['lastname']?></font></li>
      <li><font size="2">Sexe: <?php echo $row['gender']?></font></li>
       <li><font size="2">Telephone: <?php echo $row['phone_number']?></font></li>
        <li><font size="2">User Name: <?php echo $row['username']?></font></li>
         <li><font size="2">Password: <?php echo $row['password']?></font></li>
         <li><font size="2">Email: <?php echo $row['email_address']?></font></li>
      </ul>

      
      
      
      </td>
    </tr>
   
   
    
  
   
  </table>
</div>
<?php
		}
?>
</body>
</html>