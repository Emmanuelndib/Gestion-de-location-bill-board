<?php
include('auth.php');
include('db.php');
$me=$_REQUEST['id'];
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script language="javascript">
function Clickheretoprint()
{ 
  var disp_setting="toolbar=yes,location=no,directories=yes,menubar=yes,"; 
      disp_setting+="scrollbars=yes,width=600, height=300, left=100, top=25"; 
  var content_vlue = document.getElementById("print_content").innerHTML; 
  
  var docprint=window.open("","",disp_setting); 
   docprint.document.open(); 
   docprint.document.write('<html><head><title>BWB/Systeme de Gestion des Immobiliers</title>'); 
   docprint.document.write('</head><body onLoad="self.print()" style="font-size:11px; font-family:arial;"><justify>');          
   docprint.document.write(content_vlue);          
   docprint.document.write('</justify></body></html>'); 
   docprint.document.close(); 
   docprint.focus(); 
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>



</head>

<body>
<div id="print_content">
<?php
	 include('db.php');
	  include('class/class.php');
	 $leftTime=new kakuleClaudeDateCal();
	  
		$q="select *from rent_tbl where tenant_id='$me' order by re_id desc limit 1";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
                <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
<h3>Le Rapport de  locateur  <font color="#0000FF"><?php echo $row['tenant_full_name']?></font></h3>

<h3>I. LE LOYER</h3>

<font size="4">Date du debut de loyer est  : <?php echo $row['start_date']?></font><br />
<font size="4">Nombre de mois  est : <?php echo $row['day_remained']?> Mois</font><br/>
<font size="4">Date de la fin du loyer est : <?php echo $row['end_date']?></font><br/>
<font size="4">Nombre de jours qui restent : <?php echo $leftTime->diffBetweenTwoDates(date('Y-m-d'),$row['end_date']);?> jours  </font>
                    



<?php
		}
?>
  
<hr color="#FF0000"/> 
<h3>II. LES 5 DERNIERE FACTURES </h3> 
  <table width="724" border="1">
  <tr bgcolor="#0000FF">
    <td width="150"><font color="#FFFFFF">FACTURE</font></td></td>
    <td width="169"><font color="#FFFFFF">INTITULE</font></td>
    <td width="149"><font color="#FFFFFF">DATE</font></td>
    <td width="104"><font color="#FFFFFF">MONTANT</font></td>
    <td width="162"><font color="#FFFFFF">PAYE OU PAS</font></td>
  </tr>
  <?php
	 include('db.php');
	 
		$q="select *from facture_tbl where tenant_id='$me' order by fact_id desc limit 5";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
  <tr bgcolor="#FF0000">
    <td><font color="#FFFFFF"><?php echo $row['fact_from']?></font></td>
    <td><font color="#FFFFFF"><?php echo $row['fact_title']?></font></td>
    <td><font color="#FFFFFF"><?php echo $row['date']?></font></td>
    <td><font color="#FFFFFF"><?php echo $row['amount']?></font></td>
    <td><font color="#FFFFFF"><?php echo $row['pay']?></font></td>
  </tr>
  <?php
		}
  ?>
</table>

<hr color="#FF0000"/>
<h3>III. LES ENDOMMAGEMENTS ET REPARATIONS  </h3> 

<table width="730" border="1">
<tr>   
                                                
                                                <th width="25%">Type  </th>
                                                                               
                                                    <th width="25%">Endomagement </th>
                                                     <th width="25%"> Montant(Devis) </th> 
                                                    
                                                    <th width="25%" title="L’entretien a-t-il été  fait?">Fait ou Pas</th>
                                                     <th width="25%"  title="l'entretien a été fait par qui?">Fait par:</th> 
                                                    
                                                                                      
                                                </tr>



  <?php
	 include('db.php');
	 
		$q="select *from damage_tbl where tenant_id='$me' order by damage_id desc";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
            <tr> 
                                                <td><?php echo $row['damage_type']?></td>
                                                <td><?php echo $row['damage_detail']?></td>                                   
                                                    <td><?php echo $row['damage_cost']?> $</td>
                                                    
                                                     <td><?php echo $row['cofirm']?></td>
                                                     <td>  <?php echo $row['done_by']?> </td>
                                                    
                                                     
                                                                           
                                                </tr>
                                               
                                               <?php
		}
											   ?> 
</table>





</div>
<p>&nbsp;</p>

     <p><a href="javascript:Clickheretoprint()"> Cliquez pour imprimer</a></p>
    
                         
</body>
</html>