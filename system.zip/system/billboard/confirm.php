<?php
include('db.php');
$you=$_REQUEST['id'];
$kakule="select *from damage_tbl where damage_id='$you'";
$result=mysqli_query($con,$kakule);
$bwb=mysqli_fetch_array($result);


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<form action="conf_exc.php" method="post" enctype="multipart/form-data">
  <div align="center">
    <table width="501" border="0">
      <tr>
        <td width="245"></td>
        <td width="240"><input name="conf_id" type="hidden"  value="<?php echo $bwb['damage_id']?>"/></td>
      </tr>
      <tr>
        <td></td>
        <td><input name="id_tenant" type="hidden" value="<?php echo $bwb['tenant_id']?>" /></td>
      </tr>
      <tr>
        <td><font color="#FFFFFF" size="3">L’entretien a-t-il été  fait ?</font></td>
        <td>
          <input name="confirm" type="radio" value="Oui" /><font color="#FFFFFF" size="3"> Oui</font>
          <input name="confirm" type="radio" value="Non" /> <font color="#FFFFFF" size="3"> Non</font>
          
        </td>
      </tr>
      <tr>
      <td><font color="#FFFFFF" size="3">L’entretien a été  fait par qui ?</font></td>
       <td><select name="done">
       
       <option>Bayeur</option>
       <option>Bureau</option>
       <option>Locateur</option>
       </select>
       
       
       </td>
      </tr>
      
      
      <tr>
        <td><font color="#FFFFFF" size="3">La photo apres l'entretien</td>
        <td><input name="uploaded" type="file" /></td>
      </tr>
      
      <tr>
        <td></td>
        <td><input name="submit" type="submit" value="confirm" /></td>
      </tr>
  </table>
  </div>







</form>
</body>
</html>