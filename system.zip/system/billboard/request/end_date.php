<?php

require_once('../class/class.php');

$start=$_REQUEST['st_date'];
$mois=$_REQUEST['month_d'];

$datecal=new kakuleClaudeDateCal($start,$mois,'+',1);

//echo $datecal->getDate();
echo "<script>add_value('".$datecal->getDate()."');</script>";





?>

