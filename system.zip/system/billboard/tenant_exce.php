<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$f_name=$_POST['fname'];$f_name=mysqli_real_escape_string($con,$f_name);

$l_name=$_POST['lname'];$l_name=mysqli_real_escape_string($con,$l_name);
$sexe=$_POST['sexe'];$sexe=mysqli_real_escape_string($con,$sexe);
$phone=$_POST['p_number'];$phone=mysqli_real_escape_string($con,$phone);
$email_ad=$_POST['mail'];$email_ad=mysqli_real_escape_string($con,$email_ad);
	
$addr=$_POST['address'];$addr=mysqli_real_escape_string($con,$addr);


$etat=$_POST['statut'];$etat=mysqli_real_escape_string($con,$etat);
$lid=$_POST['l_id'];$lid=mysqli_real_escape_string($con,$lid);
$full_name=$_POST['full'];$full_name=mysqli_real_escape_string($con,$full_name);

$build=$_POST['conctruiction'];$build=mysqli_real_escape_string($con,$build);
$house_cat=$_POST['house_cat'];$house_cat=mysqli_real_escape_string($con,$house_cat);
$room_n=$_POST['room'];$room_n=mysqli_real_escape_string($con,$room_n);




// insert images 
	
	$rd2 = mt_rand(1000,9999)."_File";  
            $filename = basename($_FILES['uploaded']['name']);
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $newname="images/".$filename;

         move_uploaded_file($_FILES['uploaded']['tmp_name'],$newname);
	
	
$rd3 = mt_rand(1000,9999)."_File";  
            $filename = basename($_FILES['uploaded_house']['name']);
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $house_img="images/".$filename;

         move_uploaded_file($_FILES['uploaded_house']['tmp_name'],$house_img);
	






$q="insert into tenant_tbl set firstname='$f_name',lastname='$l_name',gender='$sexe',phone_number='$phone',email_adress='$email_ad',tenant_pic='$newname',adress='$addr',statut='$etat',land_name='$full_name',land_id='$lid',house_building='$build',house_category='$house_cat',room_number='$room_n',house_pic='$house_img'";
$result=mysqli_query($con,$q);


	
	}


$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> Le locateur a été enregistrer avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "view_ld2.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
}


?>
