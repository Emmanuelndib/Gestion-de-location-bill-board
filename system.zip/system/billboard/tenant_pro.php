<?php
session_start();
include('db.php');
$me=$_REQUEST['id'];

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
  <?php
	 include('db.php');
	   
		$q="select *from tenant_tbl  where tenant_id='$me'";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
  <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
  <table width="493" border="0" bgcolor="0">
    <tr>
      
      <td width="240" bgcolor="#000000"><img src="<?php echo $row['tenant_pic']?>" height="226" width="243" /> <p>&nbsp;</p>
      <h4><font color="#FFFFFF">La maison</font></h4>
      </td>
      <td width="221" bgcolor="#FFFFFF">
      <ul>
      <li><font size="2">Nom : <?php echo $row['firstname']?></font></li>
      <li><font size="2">Postnom: <?php echo $row['lastname']?></font></li>
      <li><font size="2">Sexe: <?php echo $row['gender']?></font></li>
       <li><font size="2">Etat Civil: <?php echo $row['statut']?></font></li>
       <li><font size="2">Telephone: <?php echo $row['phone_number']?></font></li>
        <li><font size="2">Email: <?php echo $row['email_adress']?></font></li>
        <h4><strong>La maison</strong></h4> 
        
        <li><font size="2">Categorie: <?php echo $row['house_category']?></font></li>
         <li><font size="2">Contruiction: <?php echo $row['house_building']?></font></li>
         <li><font size="2">N Chambre: <?php echo $row['room_number']?></font></li>
         <li><font size="2">Adresse: <?php echo $row['adress']?></font></li>
        
      </ul>

      
      
      
      </td>
    </tr>
   
   
    
  
   
  </table>
  <p>&nbsp;</p>
  <table width="493">
  <tr>
  <td width="291" bgcolor="#FFFFFF"><div align="center"><img src="<?php echo $row['house_pic']?>" height="280" width="430" /></div></td>
  
  
  </tr>
  </table>
  
  
  
  
  
  
</div>
<?php
		}
?>
</body>
</html>