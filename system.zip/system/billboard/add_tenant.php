<?php
session_start();
include('db.php');
$me=$_REQUEST['id'];
$smu="select *from land_lord_tbl where land_id='$me'";
$result=mysqli_query($con,$smu);
$kakule=mysqli_fetch_array($result);

?>





<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<p>&nbsp;</p>
<div align="center"><font size="3"><i><font color="#FFFFFF">Enregistrer un nouveau Locateurs de </font> <font color="#00FF00"><?php echo $kakule['firstname'] ?> <?php echo $kakule['lastname'] ?></font></i> </font></div></h3>

<div align="center"><form action="tenant_exce.php" method="post" enctype="multipart/form-data">
  
    <table width="422" height="244" border="0">
    <tr>
        <td width="118"></td>
        <td width="337"><label for="textfield"></label>
        <input type="hidden" name="l_id" id="textfield" value="<?php echo $kakule['land_id']?>" /></td>
      </tr>
      
      <tr>
        <td width="118"></td>
        <td width="337"><label for="textfield"></label>
        <input type="hidden" name="full" id="textfield" value="<?php echo $kakule['firstname']?> <?php echo $kakule['lastname']?>"  /></td>
      </tr>
      <tr>
      <tr>
        <td><font color="#FFFFFF" size="2">Nom</font></td>
        <td><label for="textfield"></label>
        <input type="text" name="fname" id="textfield" size="50" required="required" /></td>
      </tr>
      <tr>
        <td><font color="#FFFFFF" size="2">Postnom</font></td>
        <td><label for="textfield2"></label>
        <input type="text" name="lname" id="textfield2" size="50" required="required"/></td>
      </tr>
      <tr>
        <td><font color="#FFFFFF" size="2">Sexe</font></td>
        <td><label for="select"></label>
          <select name="sexe" id="select" size="">
            <option>Masculin</option>
            <option>Feminin</option>
        </select></td>
      </tr>
      <tr>
        <td><font color="#FFFFFF" size="2">Telephone</font></td>
        <td><label for="textfield3"></label>
        <input type="text" name="p_number" id="textfield3"  size="50" required="required"/></td>
      </tr>
      <tr>
        <td><font color="#FFFFFF" size="2">Email</font></td>
        <td><label for="textfield4"></label>
        <input type="text" name="mail" id="textfield4"  size="50" required="required"/></td>
      </tr>
      
      <tr>
        <td><font color="#FFFFFF" size="2">Etat Civil</font></td>
        <td><label for="textfield5"></label>
          <label for="select2"></label>
          <select name="statut" id="select2">
            <option>Marié</option>
            <option>Cellibateur</option>
        </select></td>
      </tr>
      
      <tr>
        <td height="36"><font color="#FFFFFF" size="2">Photo</font></td>
        <td><label for="fileField"></label>
        <input type="file" name="uploaded" id="fileField" /></td>
      </tr>
      
     
     
     
     
      
  
    </table>
  <p>&nbsp;</p>
  
    <font size="3"><i><font color="#FFFFFF">Les informations sur la maison occupée par  le locateur</font></i></font>
    <p>&nbsp;</p>
  <table width="428" height="136" border="0">
  <tr>
    <td width="120"><font color="#FFFFFF" size="2">Construction</font></td>
    <td width="338"><label for="select3"></label>
      <select name="conctruiction" id="select3">
        <option>Materiaux Durable</option>
        <option>Planches</option>
      </select></td>
  </tr>
  <tr>
    <td><font color="#FFFFFF" size="2">Type Maison</font></td>
    <td><label for="select3"></label>
      <select name="house_cat" id="select3">
        <option>Appartement</option>
        <option>Simple Maison</option>
      </select></td>
  </tr>
  
  
  <tr>
        <td><font color="#FFFFFF" size="2">N Chambre</font></td>
 
        <td><label for="textfield5"></label>
        <input type="text" name="room" id="textfield5"  size="50" required="required"/></td>
      </tr>
  <tr>
  
  
  <tr>
        <td><font color="#FFFFFF" size="2">Adresse</font></td>
 
        <td><label for="textfield5"></label>
        <input type="text" name="address" id="textfield5"  size="50" required="required"/></td>
      </tr>
      
      
       <tr>
        <td height="36"><font color="#FFFFFF" size="2">Photo </font></td>
        <td><label for="fileField"></label>
        <input type="file" name="uploaded_house" id="fileField" /></td>
      </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" name="submit" id="button" value="Valider" /></td>
  </tr>
</table>

</form>
</div>
</body>
</html>