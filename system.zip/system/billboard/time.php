<?php echo "" . date("d-m-20y h:i:s A"); 

 ?> 