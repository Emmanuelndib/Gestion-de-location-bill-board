<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$bil_localisation=$_POST['location'];$bil_localisation=mysqli_real_escape_string($con,$bil_localisation);

$bil_size=$_POST['size'];$bil_size=mysqli_real_escape_string($con,$bil_size);
$bil_price=$_POST['price'];$bil_price=mysqli_real_escape_string($con,$bil_price);
//$bil_face=$_POST['fascade'];$bil_face=mysqli_real_escape_string($con,$bil_face);

$total_price=$bil_price*$bil_size;

//$n=$_POST['mail'];$email=mysqli_real_escape_string($con,$email);




// insert images 
	
	
	
	







$q="insert into billboard_tbl set billboard_location='$bil_localisation',bill_size='$bil_size',price_metter='$bil_price',price_month='$total_price'";
$result=mysqli_query($con,$q);


	
	}


$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> Le panneau publicitaire a été enregistrer avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "add_billboard.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
}


?>
