<?php
include('db.php');


$art_id=$_REQUEST['id'];





$q="delete from land_lord_tbl where land_id='$art_id'";
$me=mysqli_query($con,$q);

//$delete_file=unlink(''.$_GET['del_img'].'');



//header('location:view_activity.php');


echo '<script>
		function redirectAction(){
			window.location = "view_loc.php";
		}
		setTimeout(redirectAction,1000);
		</script>';


?>

