<?php
include('auth.php');
include('db.php');
$me=$_SESSION['SESS_ADMIN_ID'];


?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/sample_blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:50 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
    <!DOCTYPE html>
<html lang="en">

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/sample_gallery.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:47 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />    
    <!--[if gt IE 8]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
    <![endif]-->                
    <title>Gallery - Leo - Premium Admin Template</title>
    <link rel="icon" type="image/ico" href="favicon.ico"/>
    
    <link href="css/stylesheets.css" rel="stylesheet" type="text/css" />
    
    <!--[if lte IE 7]>
        <script type='text/javascript' src='js/other/lte-ie7.js'></script>
    <![endif]-->    
    
    <script type='text/javascript' src='js/jquery/jquery.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-ui-1.10.3.custom.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='js/jquery/globalize.js'></script>
    
    <script type='text/javascript' src='js/bootstrap/bootstrap.min.js'></script>
    <script type='text/javascript' src='js/cookies/jquery.cookies.2.2.0.min.js'></script>
    
    <script type='text/javascript' src='js/fancybox/jquery.fancybox.pack.js'></script>
    <script type='text/javascript' src='js/scrollup/jquery.scrollUp.min.js'></script>

    <script type='text/javascript' src='js/plugins.js'></script>    
    <script type='text/javascript' src='js/actions.js'></script>
</head>
<body>    
    
    <div id="wrapper">
        
        <div id="header">
            
            <div class="wrap">
                
                <a href="#" class="logo"></a>
                
                <div class="buttons fl">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_layout">
                            <span class="i-layout-8"></span>                            
                        </a>
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_screen">
                            <span class="i-stretch"></span>                            
                        </a>
                    </div>                    
                </div>
                
                <div class="buttons">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-cog"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Settings</h2>
                            </div>
                            <div class="content np">      
                                <div class="row">
                                    <div class="controls-row">
                                        <div class="col-md-3">Themes:</div>
                                        <div class="col-md-9 themes">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>
                                            <a href="#" class="dark tip" data-theme="themeDark" title="Dark"></a>
                                            <a href="#" class="simple tip" data-theme="themeSimple" title="Simple"></a>
                                            <div class="help-block">On click theme will changed and saved settings</div>
                                        </div>
                                    </div>               
                                    <div class="controls-row">
                                        <div class="col-md-3">Backgrounds:</div>
                                        <div class="col-md-9 backgrounds">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>                                            
                                            <a href="#" class="b_bcrosshatch" data-back="b_bcrosshatch"></a>
                                            <a href="#" class="b_crosshatch" data-back="b_crosshatch"></a>
                                            <a href="#" class="b_cube" data-back="b_cube"></a>
                                            <a href="#" class="b_dots" data-back="b_dots"></a>
                                            <a href="#" class="b_grid" data-back="b_grid"></a>
                                            <a href="#" class="b_hline" data-back="b_hline"></a>
                                            <a href="#" class="b_simple" data-back="b_simple"></a>
                                            <a href="#" class="b_vline" data-back="b_vline"></a>
                                            <div class="help-block">On click background will changed and saved settings</div>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                            <div class="footer">
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-chat"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Messages</h2>
                            </div>
                            <div class="content npb messages minify" id="messages"></div>
                            <div class="footer">
                                <div class="side fl">
                                    <button class="btn btn-link">Show all</button>
                                </div>
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">                        
                        <div class="btn-group">                        
                            <a href="#" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                                <span class="i-forward"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="#"><span class="i-profile"></span> Profile</a></li>
                                <li><a href="#"><span class="i-tools"></span> Controls</a></li>                                
                                <li><a href="#"><span class="i-locked"></span> Lock</a></li>
                                <li><a href="#"><span class="i-forward"></span> Logout</a></li>
                            </ul> 
                        </div>
                    </div>                
                </div>
                
            </div>
            
        </div>
        
        <div id="layout">
        
            <div id="sidebar">

                <div class="user">
                    <div class="pic">
                        <img src="<?php echo $_SESSION['SESS_ADMIN_PIC']?>" height="160" width="169"/>
                    </div>
                    <p>&nbsp;</p>
                     <p>&nbsp;</p>
                    <div class="info">
                        <div class="name">
                            <a href="#">...</a>
                        </div>
                        
                        
                   
                        
                    </div>
                </div>
 <p>&nbsp;</p>
                     <p>&nbsp;</p>
                      <p>&nbsp;</p>
                     <p>&nbsp;</p>
                <ul class="navigation">
                    
                    
                    <li class="openable">
                        <a href="#">Menu</a>
                        <ul>
                            <li>
                                <a href="wlc.php">Acceuil</a>
                            </li>
                            <li>
                                <a href="my_tenant.php">Mes Locateurs</a>
                            </li>
                            <li>
                                <a href="#">Modifier le compte</a>
                            </li>
                            
                                                   
                        </ul>
                    </li> 
                              
                                                    
                                                      
                    
                    
                    
                                       
                                      
                                 
                                    
                </ul>


            </div>

            <div id="content">   
                            
                <div class="wrap">
                    
                    <div class="head">
                        <div class="info">
                            <h1>Welcome, <font color="#FF0000"> <?php echo $_SESSION['SESS_ADMIN_FIRSTNAME']?>  <?php echo $_SESSION['SESS_ADMIN_LASTNAME']?></font></h1>
                            <ul class="breadcrumb">
                                <li><a href="#">...</a></li>                                
                                <li class="active">...</li>
                            </ul>
                        </div>                                                
                    </div>                                                                    
                    
                    <div class="container">

                        <div class="row">
                            
                            <div class="col-md-12">
                                
                                <div class="block">
                                    <div class="head">
                                        <h2>Annonce</h2>
                                    </div>
                                    
                                    <div class="content">
                                    
                                     <?php
	 include('db.php');
	 
		$q="select *from  annoucement_tbl  order by annouce_id desc limit 1";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
                                       <p> <?php echo $row['annouce_detail']?></p>
                                        
                                        
                                        <?php
		}
										?>
                                        
                                    </div>
                                    
                                    
                                    <p>&nbsp;</p>
                                    
                                    
                                    <div class="content">
                                        <div class="block">
                                    <div class="head">
                                        <h2>Mes maisons et appartement déjà occupées </h2>
                                    </div>
                                    <div class="content gallery">
                                    <?php
	 include('db.php');
	   
		$q="select *from tenant_tbl where land_id='$me' order by tenant_id desc";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
					
                                        <a class="fancybox" rel="group" href="<?php echo $row['house_pic'] ?>"><img src="<?php echo $row['house_pic'] ?>" width="150" height="115" class="img-thumbnail"/></a>
                                      <?php
                                      }
									  ?>
                                        
                                        
                                                                             
                                    </div>
                                </div>
                                
                            </div>
                                
                        </div>                        
                        
                    </div>
                        
                </div>
            </div>
            
        </div>

    </div>
    
</body>

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/sample_blank.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:50 GMT -->
</html>
