<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$damge_d=$_POST['damage'];$damge_d=mysqli_real_escape_string($con,$damge_d);













$q="insert into annoucement_tbl set annouce_detail='$damge_d'";
$result=mysqli_query($con,$q);

	
	}




$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> endamagement  a été enregistré avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "anoucement.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
}



?>
