<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{








$id_t=$_POST['conf_id'];$id_t=mysqli_real_escape_string($con,$id_t);
	
$id_ok=$_POST['id_tenant'];$id_ok=mysqli_real_escape_string($con,$id_ok);


$conf=$_POST['confirm'];$conf=mysqli_real_escape_string($con,$conf);
$d_by=$_POST['done'];$d_by=mysqli_real_escape_string($con,$d_by);



// insert images 
	
	$rd2 = mt_rand(1000,9999)."_File";  
            $filename = basename($_FILES['uploaded']['name']);
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $newname="images/".$filename;

         move_uploaded_file($_FILES['uploaded']['tmp_name'],$newname);
	




$q="update damage_tbl set repair_pic='$newname',cofirm='$conf',tenant_id='$id_ok',done_by='$d_by' where damage_id='$id_t'";
$result=mysqli_query($con,$q);

	
	}




$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> endamagement  a été enregistré avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "damage.php?id='.$id_ok.'";
		}
		setTimeout(redirectAction,1000);
		</script>';
}



?>
