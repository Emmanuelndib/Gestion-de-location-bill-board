<?php

$daysLeft =0;
$fromDate = "2018-01-31";
$curDate = date('y-m-d');
$daysLeft = abs(strtotime($curDate) - strtotime($fromDate));
$days = $daysLeft/(60 * 60 * 24);
//printf("Days difference between %s and %s = %d", $fromDate, $curDate, $days);

//printf("%s and %s=%d",$days);


echo $days;



?>