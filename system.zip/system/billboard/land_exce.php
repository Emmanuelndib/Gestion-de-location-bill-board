<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$f_name=$_POST['fname'];$f_name=mysqli_real_escape_string($con,$f_name);

//$l_name=$_POST['lname'];$l_name=mysqli_real_escape_string($con,$l_name);
//$sexe=$_POST['sexe'];$sexe=mysqli_real_escape_string($con,$sexe);
$phone=$_POST['p_number'];$phone=mysqli_real_escape_string($con,$phone);
//$user_name=$_POST['uname'];$user_name=mysqli_real_escape_string($con,$user_name);
	
//$pword=$_POST['pwd'];$pword=mysqli_real_escape_string($con,$pword);


$email=$_POST['mail'];$email=mysqli_real_escape_string($con,$email);




// insert images 
	
	
	
	







$q="insert into land_lord_tbl set firstname='$f_name',phone_number='$phone',email_address='$email'";
$result=mysqli_query($con,$q);


	
	}


$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> Le client a été enregistrer avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "add_ld.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
}


?>
