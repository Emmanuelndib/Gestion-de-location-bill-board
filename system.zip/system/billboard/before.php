<?php
include('db.php');
$me=$_REQUEST['id'];



?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

<div align="center">
  <?php
	 include('db.php');
	 
		$q="select *from damage_tbl where damage_id='$me'";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
             <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
             
             <img src="<?php echo $row['damage_pic']?>" width="355" height="338"  /></div>
           </td> 
            
            
            <?php
		}
			?>
            
</body>
</html>