<?php
session_start();
include('db.php');
$me=$_REQUEST['id'];
$smu="select *from rent_tbl where re_id='$me'";
$result=mysqli_query($con,$smu);
$kakule=mysqli_fetch_array($result);

?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/form_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />    
    <!--[if gt IE 8]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
    <![endif]-->                
    <title>Form Elements - Leo - Premium Admin Template</title>
    <link rel="icon" type="image/ico" href="favicon.ico"/>
    
    <link href="css/stylesheets.css" rel="stylesheet" type="text/css" />
    
    <link rel="stylesheet" type="text/css" href="tcal.css" />
    <link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
    <!--[if lte IE 7]>
        <script type='text/javascript' src='js/other/lte-ie7.js'></script>
    <![endif]-->    
    
    <script type='text/javascript' src='js/jquery/jquery.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-ui-1.10.3.custom.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='js/jquery/globalize.js'></script>
    
    <script type='text/javascript' src='js/bootstrap/bootstrap.min.js'></script>
    <script type='text/javascript' src='js/cookies/jquery.cookies.2.2.0.min.js'></script>
    
    <script type='text/javascript' src='js/select2/select2.min.js'></script>
    <script type='text/javascript' src='js/uniform/jquery.uniform.min.js'></script>
    <script type='text/javascript' src='js/tagsinput/jquery.tagsinput.min.js'></script>
    <script type='text/javascript' src='js/multiselect/jquery.multi-select.js'></script>    
    <script type='text/javascript' src='js/ibutton/jquery.ibutton.min.js'></script>    
    <script type='text/javascript' src='js/colorpicker/colorpicker.js'></script>    
    <script type='text/javascript' src='js/timepicker/jquery-ui-timepicker-addon.js'></script>    
    
    <script type='text/javascript' src='js/scrollup/jquery.scrollUp.min.js'></script>
    
    <script type='text/javascript' src='js/plugins.js'></script>    
    <script type='text/javascript' src='js/actions.js'></script>
    
    



<script src="src/facebox.js" type="text/javascript"></script>
  <script type="text/javascript">
	jQuery(document).ready(function($) {
	  $('a[rel*=facebox]').facebox({
		loadingImage : 'src/loading.gif',
		closeImage   : 'src/closelabel.png'
	  })
	})
  </script>







<script type="text/javascript" src="js/jsLibraries.js"></script>
<script type="text/javascript" src="js/datecalculation.js"></script>
    
    <script type="text/javascript" src="tcal.js"></script>
    
    
    
    
    



</head>
<body>    
    
    <div id="wrapper">
        
        <div id="header">
            
            <div class="wrap">
                
                <a href="#" class="logo"></a>
                
                <div class="buttons fl">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_layout">
                            <span class="i-layout-8"></span>                            
                        </a>
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm c_screen">
                            <span class="i-stretch"></span>                            
                        </a>
                    </div>                    
                </div>
                
                <div class="buttons">
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-cog"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Settings</h2>
                            </div>
                            <div class="content np">      
                                <div class="row">
                                    <div class="controls-row">
                                        <div class="col-md-3">Themes:</div>
                                        <div class="col-md-9 themes">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>
                                            <a href="#" class="dark tip" data-theme="themeDark" title="Dark"></a>
                                            <a href="#" class="simple tip" data-theme="themeSimple" title="Simple"></a>
                                            <div class="help-block">On click theme will changed and saved settings</div>
                                        </div>
                                    </div>               
                                    <div class="controls-row">
                                        <div class="col-md-3">Backgrounds:</div>
                                        <div class="col-md-9 backgrounds">
                                            <a href="#" class="default tip" data-theme="" title="Default"></a>                                            
                                            <a href="#" class="b_bcrosshatch" data-back="b_bcrosshatch"></a>
                                            <a href="#" class="b_crosshatch" data-back="b_crosshatch"></a>
                                            <a href="#" class="b_cube" data-back="b_cube"></a>
                                            <a href="#" class="b_dots" data-back="b_dots"></a>
                                            <a href="#" class="b_grid" data-back="b_grid"></a>
                                            <a href="#" class="b_hline" data-back="b_hline"></a>
                                            <a href="#" class="b_simple" data-back="b_simple"></a>
                                            <a href="#" class="b_vline" data-back="b_vline"></a>
                                            <div class="help-block">On click background will changed and saved settings</div>
                                        </div>
                                    </div>                                    
                                </div>
                            </div>
                            <div class="footer">
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">
                        <a href="#" class="btn btn-primary btn-sm">
                            <span class="i-chat"></span>
                        </a>
                        <div class="popup">
                            <div class="head">
                                <h2>Messages</h2>
                            </div>
                            <div class="content npb messages minify" id="messages"></div>
                            <div class="footer">
                                <div class="side fl">
                                    <button class="btn btn-link">Show all</button>
                                </div>
                                <div class="side fr">
                                    <button class="btn btn-primary popup-close">Close</button>
                                </div>                                
                            </div>
                        </div>                        
                    </div>
                    <div class="item">                        
                        <div class="btn-group">                        
                            <a href="#" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
                                <span class="i-forward"></span>
                            </a>
                            <ul class="dropdown-menu">
                                <li><a href="#"><span class="i-profile"></span> Profile</a></li>
                                <li><a href="#"><span class="i-tools"></span> Controls</a></li>                                
                                <li><a href="#"><span class="i-locked"></span> Lock</a></li>
                                <li><a href="#"><span class="i-forward"></span> Logout</a></li>
                            </ul> 
                        </div>
                    </div>                
                </div>
                
            </div>
            
        </div>
        
        <div id="layout">
        
            <div id="sidebar">

                <div class="user">
                    <div class="pic">
                        
                         <img src="<?php echo $_SESSION['SESS_ADMIN_PIC']?>" width="80" height="70"/>
                    </div>
                    <div class="info">
                        <div class="name">
                            <a href="#">Welcome ,<?php echo $_SESSION['SESS_ADMIN_USERNAME']?></a>
                        </div>
                        
                    </div>
                </div>
 <p>&nbsp;</p>
  <p>&nbsp;</p>

    
  <ul class="navigation">
                    <li>
                        <a href="#">Accueil</a>
                    </li>
                   
                    
                    <li class="openable">
                        <a href="#">Gestion du System</a>
                        <ul>
                         
                            <li>
                             <a href="add_billboard.php">Ajouter Nouveau Panneau</a>  
                            </li>
                            
                            <li>
                             <a href="add_ld.php">Ajouter Nouveau Client</a>  
                            </li>
                            
                            
                          
                            
                                                  
                        </ul>
                    </li> 
                    <li class="openable open">
                        <a href="#">Confuguration</a>
                        <ul>
                            <li class="active">
                                <a href="add_user.php">Ajouter Utilisateur</a>
                            </li>                            
                                                                                 
                            
                                                        
                           
                        </ul>                        
                    </li>                
                                                  
                             
                               
                    
                                       
                    
                  
                                      
                </ul>

            </div>


            <div id="content">                        
                <div class="wrap">
                    
                    <div class="head">
                        <div class="info">
                            <h1> Client :<font color="#FF0000"><?php echo $kakule['land_name']?></font></h1>
                            <ul class="breadcrumb">
                                
                              
                               
                                <a href="view_rent2.php?id=<?php echo $kakule['land_id']?>"><button class="btn btn-danger" type="button">Voir les panneaux loues par <?php echo $kakule['land_name']?></button></a><a href="view_loc.php">|<button class="btn btn-primary" type="button">Clients List</button></a>
                                <p>
                              <center> <?php 
							   include('msg.php');
							   ?></center>
                            </ul>
                        </div>
                        
                        <div class="search">
                            <form action="" method="post">
                                <input type="text" class="form-control" placeholder="search..."/>                                
                                <button type="submit"><span class="i-calendar"></span></button>
                                <button type="submit"><span class="i-magnifier"></span></button>
                            </form>
                        </div>                        
                    </div>                                                                    
                    
                    <div class="container">
                        
                        <div class="row">

                            <div class="col-md-12">

                                <div class="block">
                                    <div class="head">
                                         <h2><a href="">Modifier une nouvelle  location  de <font color="#FF0000"><?php echo $kakule['land_name']?></font></a></h2>
                                        
                                       
                                        <form action="update_location.php" method="post" enctype="multipart/form-data">
                                        
                                    <div class="content np">                                        
                                        <div class="controls-row">
                                            <div class="controls-row">
                                            
                                            <div class="col-md-6"></div>
                                            <input type="hidden" name="id_ren" class="form-control" value="<?php echo $kakule['re_id']?>"  placeholder="Nom" required/>
                                        </div>  
                                           
                                        </div>

                                        <div class="controls-row">
                                            <div class="controls-row">
                                            
                                            <div class="col-md-6"></div>
                                            <input type="hidden" name="cust_id" class="form-control" value="<?php echo $kakule['land_id']?>"  placeholder="Nom" required/>
                                        </div>  
                                           
                                        </div>
                                        
                                      
                                         
                                       
                                        

                                        <div class="controls-row">
                                            <div class="col-md-3">Localisation du panneau:</div>
                                            <div class="col-md-6">
                                                <select class="form-control" name="localisation">
                                                <?php
	 include('db.php');
	   
		$q="select *from billboard_tbl";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>   
                                                <option><?php echo $row['1']?></option>
                                                    
                                                    <?php
                                                    }
                                                    ?>
                                                    
                                                </select>
                                            </div>
                                        </div>


                                        <div class="controls-row">
                                            <div class="col-md-3">Dimension:</div>
                                            <div class="col-md-6">
                                                <select class="form-control" name="size">
                                                <?php
	 include('db.php');
	   
		$q="select *from billboard_tbl";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>   
                                                <option><?php echo $row['5']?></option>
                                                    
                                                    <?php
                                                    }
                                                    ?>
                                                    
                                                </select>
                                            </div>
                                        </div>

                                        <div class="controls-row">
                                            <div class="col-md-3">Prix par mois:</div>
                                            <div class="col-md-6">
                                                <select class="form-control" name="price">
                                                <?php
	 include('db.php');
	   
		$q="select *from billboard_tbl";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
            <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>   
                                                <option><?php echo $row['4']?></option>
                                                    
                                                    <?php
                                                    }
                                                    ?>
                                                    
                                                </select>
                                            </div>
                                        </div>



                                        


                                        


                                        <div class="controls-row">
                                            <div class="col-md-3">Montant paye:</div>
                                            <div class="col-md-6"><input type="text" name="montant"  class="form-control" placeholder="" value="<?php echo $kakule['10']?>"/></div>
                                        </div> 

                                        
                                         <div class="controls-row">
                                            <div class="col-md-3">Start Date:</div>
                                            <div class="col-md-6"><input type="text"   name="start" id="start_d" class="tcal"  placeholder="" value="<?php echo $kakule['1']?>" required/></div>
                                        </div>
                                        
                                        
                                        <div class="controls-row">
                                            <div class="col-md-3">Nombre de Mois:</div>
                                            <div class="col-md-6"><input type="text" name="mois" id="month" onkeypress="end_date()"  onkeyup="end_date()" class="form-control" placeholder="" requered/></div>
                                        </div>                                        
                                        <div class="controls-row">
                                            <div class="col-md-3">End Date: </div>
                                             <div class="col-md-6"><input type="text" name="end" id="end_d" class="form-control" readonly   placeholder="" required/>  <div id="ajaxperformance"></div></div> 
                                             </div>                                       
                                        
                                    <div class="footer">
                                        <div class="side fr">
                                            <input type="submit" name="submit" class="btn btn-primary" value="Valider">
                                        </div>
                                    </div>                                    
                                </div>

                            </div>

                        </div>
                        

                           
                        
                       
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                       
                        
                        
                        
                                    </div>
                                                  
                    </div>
                        
                </div>
            </div>
            
        </div>

    </div>
    
</body>

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/form_elements.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:20 GMT -->
</html>
