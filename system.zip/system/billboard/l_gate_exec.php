<?php
	//Start session
	session_start();
	
	//Include database connection details
	require_once('config.php');
	
	//Array to store validation errors
	$errmsg_arr = array();
	
	//Validation error flag
	$errflag = false;
	
	//Connect to mysql server
	$link = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD,DB_DATABASE);
	if(!$link) {
		die('Failed to connect to server: ' . mysqli_error());
	}
	
	//Select database
	
	
	//Function to sanitize values received from the form. Prevents SQL injection
	
	
	//Sanitize the POST values
	$u_name= $_POST['login'];$u_name=mysqli_real_escape_string($link,$u_name);
	$password =$_POST['password'];$password=mysqli_real_escape_string($link,$password);
	
	//Input Validations
	
	
	//If there are input validations, redirect back to the login form
	
	
	//Create query
	$qry="SELECT * FROM  land_lord_tbl WHERE username='$u_name' AND password='$password'";
	$result=mysqli_query($link,$qry);
	
	//Check whether the query was successful or not
	if($result) {
		if(mysqli_num_rows($result) == 1) {
			//Login Successful
			session_regenerate_id();
			$member = mysqli_fetch_assoc($result);
			$_SESSION['SESS_ADMIN_ID'] = $member['land_id'];
			$_SESSION['SESS_ADMIN_USERNAME'] = $member['username'];
			$_SESSION['SESS_ADMIN_PASSWORD'] = $member['password'];
			$_SESSION['SESS_ADMIN_PIC']= $member['ld_pic'];
			$_SESSION['SESS_ADMIN_FIRSTNAME']= $member['firstname'];
			$_SESSION['SESS_ADMIN_LASTNAME']= $member['lastname'];
			session_write_close();
			echo '<script>
		function redirectAction(){
			window.location = "wlc.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
			exit();
		}else {
			//Login failed
			echo '<script>
		function redirectAction(){
			window.location = "access.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
			exit();
		}
	}else {
		die("Query failed");
	}
?>