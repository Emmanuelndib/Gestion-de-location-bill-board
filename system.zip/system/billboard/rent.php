<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="tcal.css" />

<script type="text/javascript" src="js/jquery-1.9.0.min.js"></script> 
<script type="text/javascript" src="js/jsLibraries.js"></script>
<script type="text/javascript" src="js/datecalculation.js"></script>
<script type="text/javascript" src="tcal.js"></script>
</head>

<body>
<form id="form1" name="form1" method="post" action="rente_exec.php">
  <table width="312" border="1">
    <tr>
      <td>start date</td>
      <td><label for="textfield"></label>
      <input type="text" name="start" id="start_d" class="tcal" /></td>
    </tr>
    
     <tr>
      <td>Month </td>
      <td><label for="textfield3"></label>
      <input type="text" name="mois" id="month" onkeypress="end_date()"  onkeyup="end_date()"/></td>
    </tr>
    <tr>
      <td>end date</td>
      <td><label for="textfield2"></label>
      <input type="text" name="end" id="end_d" class="" />  <div id="ajaxperformance"></div></td>
    </tr>
   
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="submit" id="button" value="Submit" /></td>
    </tr>
  </table>
</form>

<p>




<?php
	 include('db.php');
	 include('class/class.php');
	 $leftTime=new kakuleClaudeDateCal();
	   
		$q="select *from rent_tbl order by re_id limit 1";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
  <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
            
            
            <p><?php echo $row['start_date']?></p>
             <p><?php echo $row['end_date']?></p>
            <p><?php echo $row['day_remained']?></p>
            <p>Days left:<?php echo $leftTime->diffBetweenTwoDates(date('Y-m-d'),$row['end_date']); ?></p>
            <?php
		}
			?>
            
</body>
</html>