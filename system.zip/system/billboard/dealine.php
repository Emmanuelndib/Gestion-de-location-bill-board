<?php
include('auth.php');
include('db.php');
$me=$_REQUEST['id'];
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
           
<?php
	 include('db.php');
	  
	  
		$q="select *from rent_tbl where land_id='$me' order by re_id desc limit 1 ";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
                <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>

<div align="center"><h3><font color="#ffffff">Location (s) fait par: <?php echo $row['land_name']?></font></h3></div>

<?php

    }
?>
            
            <div align="center">
              <table width="540" border="1">
                <tr >
               <th bgcolor="#ffffff"><font size="3">Pannneau</font></th>
               <th bgcolor="#ffffff"><font size="3">Start Date</font></th>
               <th bgcolor="#ffffff"><font size="3">End date</font></th>
               <th bgcolor="#ffffff"><font size="3">Compteur en rebours</font></th>
                </tr>


                <?php
	 include('db.php');
	  include('class/class.php');
	 $leftTime=new kakuleClaudeDateCal();
	  
		$q="select *from rent_tbl where land_id='$me' order by re_id desc ";
	
		$resultset=mysqli_query($con,$q);
		if(mysqli_num_rows($resultset)==0){
			?>
                <?php
		}
		while($row=mysqli_fetch_array($resultset)){
			?>
                <tr>

                 <td bgcolor="#ffffff" align="center"><font size="2"><?php echo $row['6']?> </font></td>
                 <td bgcolor="#ffffff"align="center"><font size="2"><?php echo $row['1']?></font></td>
                 <td bgcolor="#ffffff"align="center"><font size="2"><?php echo $row['2']?></font></td>

                  <td bgcolor="#ffffff" align="center"><font size="3" color="#FF0000"><?php echo $leftTime->diffBetweenTwoDates(date('Y-m-d'),$row['end_date']); ?> jours</font>
                    
                
                  
    
                    
                  </td>



                </tr>
                
                
                <?php
		}
			?>
  </table>
            </div>


</body>
</html>