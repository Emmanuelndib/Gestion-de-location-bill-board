<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{



$user_name=$_POST['uname'];$user_name=mysqli_real_escape_string($con,$user_name);
	
$pword=$_POST['pwd'];$pword=mysqli_real_escape_string($con,$pword);







// insert images 
	
	$rd2 = mt_rand(1000,9999)."_File";  
            $filename = basename($_FILES['uploaded']['name']);
            $ext = substr($filename, strrpos($filename, '.') + 1);
            $newname="images/".$filename;

         move_uploaded_file($_FILES['uploaded']['tmp_name'],$newname);
	
	







$q="insert into user_tbl set user_name='$user_name',password='$pword',user_pic='$newname'";
$result=mysqli_query($con,$q);


	
	}


$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> Le nouveau utilisateur a été enregistrer avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "add_user.php";
		}
		setTimeout(redirectAction,1000);
		</script>';
}


?>
