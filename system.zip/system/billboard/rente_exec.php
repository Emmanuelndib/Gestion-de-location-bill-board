<?php
session_start();
include('db.php');
if(isset($_POST['submit']))
{


$s_date=$_POST['start'];$s_date=mysqli_real_escape_string($con,$s_date);

$end_d=$_POST['end'];$end_d=mysqli_real_escape_string($con,$end_d);


$day=$_POST['mois'];$day=mysqli_real_escape_string($con,$day);

//$t_name=$_POST['fname'];$t_name=mysqli_real_escape_string($con,$t_name);

$landlord=$_POST['land_full'];$landlord=mysqli_real_escape_string($con,$landlord);
$customer_id=$_POST['id_land'];$customer_id=mysqli_real_escape_string($con,$customer_id);
	





$bil_localisation=$_POST['localisation'];$bil_localisation=mysqli_real_escape_string($con,$bil_localisation);

$bil_size=$_POST['size'];$bil_size=mysqli_real_escape_string($con,$bil_size);
$bil_price=$_POST['price'];$bil_price=mysqli_real_escape_string($con,$bil_price);
//$bil_face=$_POST['fascade'];$bil_face=mysqli_real_escape_string($con,$bil_face);

$paid_amount=$_POST['montant'];$paid_amount=mysqli_real_escape_string($con,$paid_amount);


$q="insert into rent_tbl set start_date='$s_date',end_date='$end_d',day_remained='$day',land_id='$customer_id',land_name='$landlord',billboard_location='$bil_localisation',price_month='$bil_price',bill_size='$bil_size',amount='$paid_amount'";
$result=mysqli_query($con,$q);



$q="insert into transaction_tbl set start_date='$s_date',end_date='$end_d',day_remained='$day',land_id='$customer_id',land_name='$landlord',billboard_location='$bil_localisation',price_month='$bil_price',bill_size='$bil_size',amount='$paid_amount'";
$result=mysqli_query($con,$q);


	}




$errmsg_arr[] = '<div class="alert alert-success"> <strong>Fait!</strong> la location a été enregistré avec succès ...
                                    <button type="button" class="close" data-dismiss="alert">&times;</button></div>';
		$errflag = true;
	if($errflag) {
		$_SESSION['ERRMSG_ARR'] = $errmsg_arr;
		session_write_close();	
	
	
	
	
	echo '<script>
		function redirectAction(){
			window.location = "rent2.php?id='.$customer_id.'";
		}
		setTimeout(redirectAction,1000);
		</script>';
}



?>
