<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/sample_login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:46 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=utf-8" /><!-- /Added by HTTrack -->
<head>        
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />    
    <!--[if gt IE 8]>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />        
    <![endif]-->                
    <title>Login - Leo - Premium Admin Template</title>
    <link rel="icon" type="image/ico" href="favicon.ico"/>
    
    <link href="css/stylesheets.css" rel="stylesheet" type="text/css" />
    
    <!--[if lte IE 7]>
        <script type='text/javascript' src='js/other/lte-ie7.js'></script>
    <![endif]-->    
    
    <script type='text/javascript' src='js/jquery/jquery.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-ui-1.10.3.custom.min.js'></script>
    <script type='text/javascript' src='js/jquery/jquery-migrate.min.js'></script>
    <script type='text/javascript' src='js/jquery/globalize.js'></script>
    
    <script type='text/javascript' src='js/bootstrap/bootstrap.min.js'></script>
    <script type='text/javascript' src='js/cookies/jquery.cookies.2.2.0.min.js'></script>
    
    <script type='text/javascript' src='js/scrollup/jquery.scrollUp.min.js'></script>
    
    <script type='text/javascript' src='js/plugins.js'></script>    
    <script type='text/javascript' src='js/actions.js'></script>
</head>
<body>        
    <div id="wrapper" class="screen_wide sidebar_off">       
        <div id="layout">
            <div id="content">                        
                <div class="wrap nm">            
                    
                    <div class="signin_block">
                        <div class="row">
                            <div class="alert alert-info">
                                 Ne dit a personne votre mot de passe 
                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                            <div class="block">
                                <div class="head">
                                    <h2>connectez vous </h2>                                    
                                    <ul class="buttons">                                        
                                        <li><a href="#" class="tip" title="Contact administrator"><i class="i-warning"></i></a></li>
                                        <li><a href="#" class="tip" title="Forget your password?"><i class="i-locked"></i></a></li>
                                    </ul>                                     
                                </div>
                                <form action="l_gate_exec.php" method="post" enctype="multipart/form-data">
                                <div class="content np">
                                    <div class="controls-row">
                                        <div class="col-md-3">Utilisateur:</div>
                                        <div class="col-md-9"><input type="text" name="login" class="form-control" required/></div>
                                    </div>
                                    <div class="controls-row">
                                        <div class="col-md-3">Mot de Passe:</div>
                                        <div class="col-md-9"><input type="password" name="password" class="form-control" required/></div>
                                    </div>                                
                                </div>
                                <div class="footer">
                                    <div class="side fl">
                                        <label class="checkbox">
                                            <input type="checkbox" name="kmsi"/> Keep me signed in
                                        </label>
                                    </div>
                                    <div class="side fr">
                                       
                                        <input type="submit" name="submit" class="btn btn-primary" value="connexiom"/>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>               
        
    </div>
    
</body>

<!-- Mirrored from aqvatarius.com/themes/leo_v14/html/sample_login.html by HTTrack Website Copier/3.x [XR&CO'2014], Tue, 01 Nov 2016 11:22:46 GMT -->
</html>
