<?php
$con=mysqli_connect("localhost","root","","billboard_db");
//mysql_select_db('') or die('db connection fail'.mysql_error);
?>